from flask import Flask, Response, send_file
from flask_cors import CORS
import io
import threading
import time
import picamera

app = Flask(__name__)
CORS(app)

# Global camera instance and lock
camera_lock = threading.Lock()
camera = None
recording = False

def initialize_camera():
    global camera
    if camera is None:
        camera = picamera.PiCamera()
        camera.resolution = (640, 480)
        camera.framerate = 24
        time.sleep(2)  # Camera warm-up time

@app.route('/capture_photo')
def capture_photo():
    with camera_lock:
        initialize_camera()
        stream = io.BytesIO()
        camera.capture(stream, format='jpeg', use_video_port=True)
        stream.seek(0)
    return send_file(stream, mimetype='image/jpeg')

def gen_frames():
    with camera_lock:
        initialize_camera()
    stream = io.BytesIO()
    for _ in camera.capture_continuous(stream, format='jpeg', use_video_port=True):
        with camera_lock:
            if not streaming:
                break
        stream.seek(0)
        frame = stream.read()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        stream.seek(0)
        stream.truncate()
        time.sleep(0.05)  # Adjust frame rate as needed

streaming = False

@app.route('/video_feed')
def video_feed():
    global streaming
    with camera_lock:
        streaming = True
    return Response(gen_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/start_recording', methods=['POST'])
def start_recording():
    with camera_lock:
        global camera, recording
        initialize_camera()
        if not recording:
            timestamp = int(time.time())
            filename = f'/home/pi/videos/recording_{timestamp}.h264'
            camera.start_recording(filename, splitter_port=2)
            recording = True
            return 'Recording started', 200
        else:
            return 'Recording already in progress', 400

@app.route('/stop_recording', methods=['POST'])
def stop_recording():
    with camera_lock:
        global camera, recording
        if recording:
            camera.stop_recording(splitter_port=2)
            recording = False
            return 'Recording stopped', 200
        else:
            return 'No recording in progress', 400

@app.route('/shutdown', methods=['POST'])
def shutdown():
    with camera_lock:
        global camera, recording, streaming
        if recording:
            camera.stop_recording(splitter_port=2)
            recording = False
        streaming = False
        if camera:
            camera.close()
            camera = None
    return 'Camera shutdown', 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, threaded=True)